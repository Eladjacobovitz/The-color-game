module.exports = {
    dbUserName: process.env.dbUserName || "practice",
    dbPassword: process.env.dbPassword || "WEB12345",
    serverPort: process.env.PORT || 5000
}