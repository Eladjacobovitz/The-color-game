const express = require('express')
const bodyParser = require('body-parser')
let dbModule = require('./db');
dbModule.connectToDb();

const app = express()
app.use(bodyParser.json())

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});

app.get('/', function(req, res) {
  res.send("Server.")
});

app.post("/save", (req, res) => {
  res.sendStatus(dbModule.addItem(req.body))
})

app.get("/getAll", (req, res) => {
  dbModule.getAllItems(function(err, values) {
    if (err) res.send("Error.")
    else res.send(values)
  })
})

app.listen(process.env.PORT || 5555, () => console.log('server running on port', process.env.PORT || 5555));

